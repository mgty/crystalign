<?php
get_header();




if (have_posts()) : while(have_posts()) : the_post(); ?>
  <?php get_template_part('content', get_post_format()); ?>
<?php endwhile; else : ?>
  <div id="post-<?php the_ID(); ?>" <?php post_class('no-posts'); ?>>
      <h3>No Posts found</h3>
  </div>
<?php endif;



get_footer();?>