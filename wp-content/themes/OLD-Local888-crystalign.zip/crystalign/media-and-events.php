<?php 
/*
    Template Name: Media & Events
*/

get_header();?>


<div class="header-img-container">
	<img 
	class="header-img" 
	role="banner" 
	src="<?php echo get_field('header_image')['url'];?>"	
	>
	<hr class="horizontal-line">


<div class="container">
    <div class="row">
            <div class="col">

                <div class="vertical-center">
                    <form action="http://crystalignchiropractic.fullslate.com/">
                        <button class="appointment-button btn button">Schedule Appointment</button>
                    </form>
                </div>
                <p class="page-body-title"><?php the_title();?></p>
            </div>
    </div>
</div>


<div class="container">
    <div class="row">
            <div class="body-text col">
                <?php if (have_posts()) : while(have_posts()) : the_post();?>

                <?php the_content();?>

                <?php endwhile; endif;?>
            </div>
    </div>
</div>


<?php get_footer();?>