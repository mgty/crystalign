<?php

function wpb_widgets_init() {
 
    register_sidebar( array(
        'name'          => 'Custom Header Widget Area',
        'id'            => 'custom-header-widget',
        'before_widget' => '<div class="chw-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="chw-title">',
        'after_title'   => '</h2>',
    ) );
 
}
add_action( 'widgets_init', 'wpb_widgets_init' );

function load_stylesheets(){

    wp_register_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css',
        array(), false, 'all');

    wp_enqueue_style('bootstrap');


    wp_register_style('style', get_template_directory_uri() . '/style.css',
        array(), false, 'all');

    wp_enqueue_style('style');
}
add_action('wp_enqueue_scripts', 'load_stylesheets');


add_action('wp_enqueue_scripts', 'register_myscripts_scripts');
function register_myscripts_scripts(){
    wp_enqueue_script('jquery'); 
    
    wp_register_script('bootstrap', get_stylesheet_directory_uri() . '/js/bootstrap.min.js', array(), false, true);
    wp_enqueue_script( 'bootstrap' );
    
    wp_register_script('collapse', get_stylesheet_directory_uri() . '/js/collapse.js', array(), false, true);
    wp_enqueue_script( 'collapse' );

}



function include_jquery(){
    wp_deregister_script('jquery');
    wp_enqueue_script('jquery', get_template_directory_uri() . '/js/jquery-3.4.1.min.js', '', 1, true);
}
add_action('wp_enqueue_scripts', 'include_jquery');


function loadjs(){
    wp_register_script('customjs', get_template_directory_uri() . '/js/scripts.js', '', 1, true);
    wp_enqueue_script('customjs');
}
add_action('wp_enqueue_scripts', 'loadjs');



function enqueue_fa_script(){
    wp_enqueue_script('fascript', 'https://kit.fontawesome.com/18903e3052.js');
}
add_action('wp_enqueue_scripts', 'enqueue_fa_script');

add_theme_support('menus');


register_nav_menus(
    #add menu location options in the dashboard
    array(
        'top-menu' => __('Top Menu', 'theme'),
        'footer-menu' => __('Footer Menu', 'theme'),
    )
);


/**
 * Register Custom Navigation Walker
 */
function register_navwalker(){
    require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
}
add_action( 'after_setup_theme', 'register_navwalker' );




