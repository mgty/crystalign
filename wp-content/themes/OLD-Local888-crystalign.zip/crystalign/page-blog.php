<?php 
/*
    Template Name: Craniosacral
*/

get_header();?>
<div class="header-img-container container-fluid">
	<img 
	class="header-img" 
	role="banner" 
	src="<?php echo get_field('header_image')['url'];?>"	
	>
	<hr class="horizontal-line">

</div>

<div class="container">
    <div class="row">
            <div class="col">

                <div class="vertical-center">
                    <form action="http://crystalignchiropractic.fullslate.com/">
                        <button class="appointment-button btn button">Schedule Appointment</button>
                    </form>
                </div>
                <p class="page-body-title"><?php the_title();?></p>
                <article class="blog-page">

					<?php // Display blog posts on any page @ https://m0n.co/l
					$temp = $wp_query; $wp_query= null;
					$wp_query = new WP_Query(); $wp_query->query('posts_per_page=5' . '&paged='.$paged);
					while ($wp_query->have_posts()) : $wp_query->the_post(); ?>

					<p class="page-body-title"><a href="<?php the_permalink(); ?>" title="Read more"><?php the_title(); ?></a></p>
					<?php the_excerpt(); ?>

					<?php endwhile; ?>

					<?php if ($paged > 1) { ?>

					<nav id="nav-posts">
						<div class="prev"><?php next_posts_link('&laquo; Previous Posts'); ?></div>
						<div class="next"><?php previous_posts_link('Newer Posts &raquo;'); ?></div>
					</nav>

					<?php } else { ?>

					<nav id="nav-posts">
						<div class="prev"><?php next_posts_link('&laquo; Previous Posts'); ?></div>
					</nav>

					<?php } ?>

					<?php wp_reset_postdata(); ?>

				</article>
            </div>
    </div>
</div>



<?php get_footer();?>